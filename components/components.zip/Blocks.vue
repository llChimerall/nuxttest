<template>
<div class="Title">
  <h2>
  Feed
  </h2>


  </div>
</template>

<script>

</script>

<style>
.h2 {
  
}
</style>